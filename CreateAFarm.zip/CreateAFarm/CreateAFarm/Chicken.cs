﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CreateAFarm
{
    class Chicken
    {
        public void Speak()
        {
            Console.WriteLine("Hi my name is Chuck, and I am a chicken. I say cluck.");
        }
        public void Eat()
        {
            Console.WriteLine("I eat oats and grains.");
        }
        public void Product()
        {
            Console.WriteLine("I live around the farm until I get fat enough and the humans eat me.");
        }
        public void Chase()
        {
            Console.WriteLine("If you make me mad I will chase you arond the farm.\n");
        }
    }
}

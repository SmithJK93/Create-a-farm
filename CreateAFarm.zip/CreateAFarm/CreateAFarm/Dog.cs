﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CreateAFarm
{
    class Dog
    {
        public void Speak()
        {
            Console.WriteLine("Hi my name is Ralph, and I am a dog. I say woof.");

        }
        public void Eat()
        {
            Console.WriteLine("I eat dog food.");
        }
        public void Product()
        {
            Console.WriteLine("I keep the tiny humans entertained!");
        }
        public void Sleep()
        {
            Console.WriteLine("When it's to hot to play I lay around the farm house and sleep.\n");
        }

    }
    
}

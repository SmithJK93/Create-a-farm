﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CreateAFarm
{
    class Cow
    {


        public void Speak()
        {
            Console.WriteLine("Hi my name is Hank, and I am a cow. I say mooooo.");
        }
        public void Eat()
        {
            Console.WriteLine("I eat hay and grass.");
        }
        public void Product()
        {
            Console.WriteLine("I live around the farm until I get old enough and the humans eat me.");
        }
        public void Nice()
        {
            Console.WriteLine("I am a very nice animal and I love head rubs.\n");
        }
    }
}

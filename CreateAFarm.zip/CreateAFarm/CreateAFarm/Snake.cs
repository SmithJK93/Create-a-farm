﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CreateAFarm
{
    class Snake
    {
        public void Speak()
        {
            Console.WriteLine("Hi my name is Boa, and I am a snake. I say hisss.");
        }
        public void Eat()
        {
            Console.WriteLine("I eat pesky rodents to keep them out the farm house.");
        }
        public void Product()
        {
            Console.WriteLine("The humans keep me around because I am there personal pest control");
        }
        public void Danger()
        {
            Console.WriteLine("Dont mess with me because I have a nasty bite!\n");
        }
    }
}

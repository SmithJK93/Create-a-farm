﻿using System;

namespace CreateAFarm
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Smith's Farm\n");
            Dog farmDog = new Dog();
            farmDog.Speak();
            farmDog.Eat();
            farmDog.Product();
            farmDog.Sleep();

            Snake farmSnake = new Snake();
            farmSnake.Speak();
            farmSnake.Eat();
            farmSnake.Product();
            farmSnake.Danger();

            Chicken farmChicken = new Chicken();
            farmChicken.Speak();
            farmChicken.Eat();
            farmChicken.Product();
            farmChicken.Chase();

            Cow farmCow = new Cow();
            farmCow.Speak();
            farmCow.Eat();
            farmCow.Product();
            farmCow.Nice();

            Console.WriteLine("Thanks for stopping by! Have a nice day.");
        }
        
    }
}
